/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package utility;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

/**
 *
 * @author raushan
 */
public class loginfun {
 public static boolean validate(String s1,String s2) 
	{
	boolean Status=false;	
	try {
		Class.forName("com.mysql.jdbc.Driver");
		Connection con;
                con = DriverManager.getConnection("jdbc:mysql://localhost:3306/adworld","root","");
		PreparedStatement ps=con.prepareStatement("select user,pass from signup where user=? and pass=?");
		ps.setString(1,s1);
		ps.setString(2,s2);
		ResultSet rs=ps.executeQuery();
		Status=rs.next();
	} 
	catch (Exception e) 
	{
		// TODO: handle exception
	
		System.out.print(e);
	}return Status;
	}   
}
